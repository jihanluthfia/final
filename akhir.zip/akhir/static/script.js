document.addEventListener('DOMContentLoaded', function() {
    // Load shopping items on page load
    fetchShoppingItems();

    // Add event listener for the add item button
    document.getElementById('add-item-btn').addEventListener('click', function() {
        addItem();
    });
});

function fetchShoppingItems() {
    fetch('/api/shopping/')
        .then(response => response.json())
        .then(data => displayShoppingItems(data.items));
}

function displayShoppingItems(items) {
    const shoppingList = document.getElementById('shopping-list');
    shoppingList.innerHTML = '';

    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'item';
        itemDiv.innerHTML = `
            <span>${item.name} - $${item.price}</span>
            <button class="btn" onclick="deleteItem(${item.id})">Delete</button>
        `;
        shoppingList.appendChild(itemDiv);
    });
}

function addItem() {
    const name = prompt('Enter item name:');
    const price = parseFloat(prompt('Enter item price:'));
    
    if (name && !isNaN(price)) {
        fetch('/api/shopping/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name: name,
                price: price
            })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            fetchShoppingItems();
        });
    } else {
        alert('Invalid input. Please enter a valid item name and price.');
    }
}

function deleteItem(itemId) {
    fetch(`/api/shopping/${itemId}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        fetchShoppingItems();
    });
}
