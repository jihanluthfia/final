from flask import request
from flask_restful import Resource, Api

from .models import ShoppingItem

shopping_items = []

class ShoppingListResource(Resource):
    def get(self):
        return {"items": [item.__dict__ for item in shopping_items]}

    def post(self):
        data = request.get_json()
        item = ShoppingItem(id=len(shopping_items) + 1, name=data["name"], price=data["price"])
        shopping_items.append(item)
        return {"message": "Item added successfully"}

class ShoppingItemResource(Resource):
    def get(self, item_id):
        item = next((item for item in shopping_items if item.id == item_id), None)
        if item:
            return item.__dict__
        else:
            return {"message": "Item not found"}, 404

    def put(self, item_id):
        data = request.get_json()
        item = next((item for item in shopping_items if item.id == item_id), None)
        if item:
            item.name = data["name"]
            item.price = data["price"]
            return {"message": "Item updated successfully"}
        else:
            return {"message": "Item not found"}, 404

    def delete(self, item_id):
        global shopping_items
        shopping_items = [item for item in shopping_items if item.id != item_id]
        return {"message": "Item deleted successfully"}
