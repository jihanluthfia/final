from flask import Flask
from flask_restful import Api
from .routes import ShoppingListResource, ShoppingItemResource

app = Flask(__name__)
api = Api(app)

api.add_resource(ShoppingListResource, '/shopping')
api.add_resource(ShoppingItemResource, '/shopping/<int:item_id>')
