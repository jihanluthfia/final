import os
import connexion
from flask_sqlalchemy import SQLAlchemy

# Inisialisasi aplikasi Connexion
app = connexion.FlaskApp(__name__, specification_dir='./')
app.add_api('swagger.yml')  # Gunakan file swagger.yml sebagai spesifikasi API

# Tambahkan konfigurasi untuk SQLAlchemy
app.app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shopping.db'
app.app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inisialisasi objek SQLAlchemy
db = SQLAlchemy(app.app)

class ShoppingItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)

# Endpoint dan logika lainnya tetap sama

if __name__ == '__main__':
    with app.app.app_context():
        db.create_all()

    # Gunakan metode run() dari objek FlaskApp di Connexion
    app.run(debug=True)
